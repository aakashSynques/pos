import axios from "axios";
import {
  CCardHeader,
  CLink,
  CCardBody,
  CCard,
  CModal,
  CModalHeader,
  CModalFooter,
  CModalTitle,
  CModalBody,
  CNavItem,
  CNav,
  CNavLink,
  CTabContent,
  CTabPane,
  CButton,
} from "@coreui/react";
import React, { useEffect, useState } from "react";
import { BeatLoader } from "react-spinners";
import CounterSale from "./recentsale/CounterSale";
import OnTable from "./recentsale/OnTable";
import PickUp from "./recentsale/PickUp";
import HomeDelivery from "./recentsale/HomeDelivery";
import RazorPay from "./recentsale/RazorePay";
import Zometo from "./recentsale/Zometo";
import Swiggy from "./recentsale/Swiggy";
import ReturnBIll from "./recentsale/ReturnBIll";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

const RecentInvoice = () => {
  const [booking, setBooking] = useState(false);
  const [recentBooking, setRecentBooking] = useState([]);
  const [loading, setLoading] = useState(true);
  const [networkError, setNetworkError] = useState(false);

  const [activeKey, setActiveKey] = useState(1);

  const outlet_id = useSelector(
    (state) => state.selectedOutletId.selectedOutletId
  );

  // const counterSaleCounts = {
  //   true: 0, // Initialize counter for true (delivery mode 1)
  // };
  // // const counterOnTable = {
  // //   true: 0,
  // // };
  // const counterOnTable = {
  //   true: 0, // Represents delivery mode 2 and payMode not 24
  // };
  // const counterPickUp = {
  //   true: 0,
  // };
  // const counterHomeDelivery = {
  //   true: 0,
  // };
  // const counterZomato = {
  //   true: 0,
  // };
  // const counterSwiggy = {
  //   true: 0,
  // };

  // recentBooking.forEach(({ sales_json }) => {
  //   try {
  //     const parsedSalesJson = JSON.parse(sales_json);
  //     // counter salesd Notification
  //     if (parsedSalesJson.cartSumUp.deliveryMode) {
  //       const deliveryMode = parsedSalesJson.cartSumUp.deliveryMode === "1"; // true or false
  //       if (counterSaleCounts.hasOwnProperty(deliveryMode)) {
  //         counterSaleCounts[deliveryMode]++;
  //       }

  //       // // on Table Notification
  //       // const deliveryModeTable =
  //       //   parsedSalesJson.cartSumUp.deliveryMode === "2";

  //       // if (counterOnTable.hasOwnProperty(deliveryModeTable)) {
  //       //   counterOnTable[deliveryModeTable]++;
  //       // }

  //       // Pick Up Notification
  //       const deliveryModePickUp =
  //         parsedSalesJson.cartSumUp.deliveryMode === "3";

  //       if (counterPickUp.hasOwnProperty(deliveryModePickUp)) {
  //         counterPickUp[deliveryModePickUp]++;
  //       }

  //       // Home Delivery Notification
  //       const deliveryModeHomeDelivery =
  //         parsedSalesJson.cartSumUp.deliveryMode === "4";

  //       if (counterHomeDelivery.hasOwnProperty(deliveryModeHomeDelivery)) {
  //         counterHomeDelivery[deliveryModeHomeDelivery]++;
  //       }
  //       // Zomato Delivery Notification
  //       const zomatoDelivery =
  //         parsedSalesJson.selectedCustomerJson.customer_name.slice(0, 6) ==
  //         "ZOMATO";
  //       if (counterZomato.hasOwnProperty(zomatoDelivery)) {
  //         counterZomato[zomatoDelivery]++;
  //       }
  //       // Swiggy Delivery Notification
  //       const swiggyDelivery =
  //         parsedSalesJson.selectedCustomerJson.customer_name.slice(0, 6) ==
  //         "SWIGGY";
  //       if (counterSwiggy.hasOwnProperty(swiggyDelivery)) {
  //         counterSwiggy[swiggyDelivery]++;
  //       }

  //       // on Table Notification
  //       const deliveryModeTable =
  //         (parsedSalesJson.cartSumUp.deliveryMode === "2" &&
  //           parsedSalesJson.cartSumUp.payDetails == undefined) ||
  //         // parsedSalesJson.cartSumUp.payDetails &&
  //         (parsedSalesJson.cartSumUp.deliveryMode === "2" &&
  //           parsedSalesJson.cartSumUp.payDetails[0].payMode !== "24");
  //       if (counterOnTable.hasOwnProperty(deliveryModeTable)) {
  //         counterOnTable[deliveryModeTable]++;
  //       }
  //     }
  //   } catch (error) {
  //     // console.error("Error parsing sales_json:", error);
  //     return false;
  //   }
  // });
  // const getPaymode = () => {
  //   let payModes = [];
  //   recentBooking.forEach(({ sales_json }) => {
  //     try {
  //       const parsedSalesJson = JSON.parse(sales_json);

  //       if (parsedSalesJson.cartSumUp.payDetails) {
  //         const payDetails = parsedSalesJson.cartSumUp.payDetails;
  //         if (payDetails.length > 0) {
  //           const payMode =
  //             payDetails[0].payMode == "24" ? payDetails[0] : null;
  //           payModes.push(payMode);
  //         }
  //       }
  //     } catch (error) {
  //       console.error("Error parsing sales_json:", error);
  //     }
  //   });
  //   const filteredPayModes = payModes.filter(Boolean);
  //   return filteredPayModes; // Return the array of payMode values
  // };

  // const payModeArray = getPaymode(); // Call the function to get the payMode values

  const getAllRecentInvoices = async () => {
    try {
      const token = localStorage.getItem("pos_token");
      const headers = {
        Authorization: `Bearer ${token}`,
      };
      setLoading(true);
      const response = await axios.post(
        "http://posapi.q4hosting.com/api/order/recent",
        { outlet_id },
        { headers }
      );
      setRecentBooking(response.data.recentOrders);
      setLoading(false);
      setNetworkError(false);
    } catch (err) {
      console.log(err);
      if (err.response.data.message == "No Recent Orders Found.") {
        console.log("No Returned Orders Found.");
        setNetworkError(true);
        setLoading(false);
      } else if (err.response.data.message == "Outlet Id Required.") {
        setLoading(true);
        console.log(err);
      } else {
        console.log(err);
        setNetworkError(true);
        setLoading(false);
      }
    }
  };
  useEffect(() => {
    getAllRecentInvoices();
  }, [outlet_id]);

  return (
    <>
      <CCard className="invoice-card">
        <CCardHeader className="invoice-card">
          Recent Invoice(s)
          <CLink
            className="text-primary pull-right"
            onClick={() => setBooking(!booking)}
          >
            <i className="fa fa-external-link fa-xs"></i>
          </CLink>
        </CCardHeader>

        {networkError === true && (
          <CCardBody style={{ display: "flex" }}>
            <div>
              <medium className="text-danger">No Recent Invoices..</medium>
            </div>
          </CCardBody>
        )}

        {loading === true && (
          <CCardBody style={{ display: "flex" }}>
            <BeatLoader
              color="red"
              loading={true}
              size={8}
              style={{ marginTop: "1%", marginRight: "2%" }}
            />

            <div>
              <medium className="text-danger">Loading Recent Invoices..</medium>
            </div>
          </CCardBody>
        )}

        {loading === false && networkError === false && (
          <div id="DB_RecentPunchedInvoice">
            <table width="100%" className="table table-bordered ongoing">
              <tbody>
                {recentBooking
                  .slice(0, 10)
                  .map(({ invoice_no, sales_json }) => {
                    return (
                      <tr>
                        <td>
                          {sales_json.cartSumUp.deliveryMode == "1" ? (
                            <strong
                              className="status-btn"
                              style={{
                                fontWeight: "bold",
                                fontSize: "1em",
                                color: "white",
                                backgroundColor: "#f0ad4e",
                                height: "2%",
                                width: "2%",
                              }}
                            >
                              Cs
                            </strong>
                          ) : sales_json.cartSumUp.deliveryMode == "2" ? (
                            <strong
                              className="status-btn"
                              style={{
                                fontWeight: "bold",
                                fontSize: "1em",
                                color: "white",
                                backgroundColor: "#28819e",
                                height: "2%",
                                width: "2%",
                              }}
                            >
                              OT
                            </strong>
                          ) : sales_json.cartSumUp.deliveryMode == "3" ? (
                            <strong
                              className="status-btn"
                              style={{
                                fontWeight: "bold",
                                fontSize: "1em",
                                color: "white",
                                backgroundColor: "green",
                                height: "2%",
                                width: "2%",
                              }}
                            >
                              PU
                            </strong>
                          ) : sales_json.cartSumUp.deliveryMode == "4" ? (
                            <strong
                              className="status-btn"
                              style={{
                                fontWeight: "bold",
                                fontSize: "1em",
                                color: "white",
                                backgroundColor: "#26b99a",
                                height: "2%",
                                width: "2%",
                              }}
                            >
                              HD
                            </strong>
                          ) : null}
                        </td>
                        <td>
                          <Link to="" className="text-primary text-link">
                            {invoice_no}
                            <br />
                          </Link>
                          <small>
                            {sales_json.selectedCustomerJson.customer_name}(
                            {sales_json.selectedCustomerJson.mobile})
                          </small>
                        </td>
                        <td
                          style={{
                            fontWeight: "bold",
                            color: "black",
                          }}
                        >
                          <bold>
                            <span
                              style={{
                                paddingRight: "3px",
                              }}
                            >
                              &#8377;
                            </span>
                            {Number(sales_json.cartSumUp.grandTotal).toFixed(2)}
                          </bold>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="#f0ad4e"
                            viewBox="0 0 66 66"
                            stroke="#333"
                          >
                            <path d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
                          </svg>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        )}
      </CCard>
      <CModal size="xl" visible={booking} onClose={() => setBooking(false)}>
        <CModalHeader onClose={() => setBooking(false)}>
          <CModalTitle>Recent Sales List</CModalTitle>
        </CModalHeader>
        <CModalBody>
          <CNav variant="pills" role="tablist">
            <CNavItem>
              <CNavLink
                active={activeKey === 1}
                onClick={() => setActiveKey(1)}
              >
                Counter Sale{" "}
                {/* <span className="badge"> {counterSaleCounts[true]}</span> */}
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                active={activeKey === 2}
                onClick={() => setActiveKey(2)}
              >
                {/* On Table <span className="badge"> {counterOnTable[true]}</span> */}
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                active={activeKey === 3}
                onClick={() => setActiveKey(3)}
              >
                {/* Pick UP <span className="badge"> {counterPickUp[true]}</span> */}
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                active={activeKey === 4}
                onClick={() => setActiveKey(4)}
              >
                Home Delivery{" "}
                {/* <span className="badge"> {counterHomeDelivery[true]}</span> */}
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                active={activeKey === 5}
                onClick={() => setActiveKey(5)}
              >
                {/* Razorpay <span className="badge"> {payModeArray.length}</span> */}
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                active={activeKey === 6}
                onClick={() => setActiveKey(6)}
              >
                {/* Zomato <span className="badge"> {counterZomato[true]}</span> */}
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                active={activeKey === 7}
                onClick={() => setActiveKey(7)}
              >
                {/* Swiggy<span className="badge"> {counterSwiggy[true]}</span> */}
              </CNavLink>
            </CNavItem>
            <CNavItem>
              <CNavLink
                active={activeKey === 8}
                onClick={() => setActiveKey(8)}
              >
                Return Bills <span className="badge"> 0</span>
              </CNavLink>
            </CNavItem>
          </CNav>

          <CTabContent>
            <CTabPane
              role="tabpanel"
              aria-labelledby="countersale"
              visible={activeKey === 1}
            >
              <CounterSale recentBooking={recentBooking} />
            </CTabPane>

            <CTabPane
              role="tabpanel"
              aria-labelledby="ontable"
              visible={activeKey === 2}
            >
              <OnTable recentBooking={recentBooking} />
            </CTabPane>

            <CTabPane
              role="tabpanel"
              aria-labelledby="pickup"
              visible={activeKey === 3}
            >
              <PickUp recentBooking={recentBooking} />
            </CTabPane>

            <CTabPane
              role="tabpanel"
              aria-labelledby="homedelivery"
              visible={activeKey === 4}
            >
              <HomeDelivery recentBooking={recentBooking} />
            </CTabPane>

            <CTabPane
              role="tabpanel"
              aria-labelledby="razorpay"
              visible={activeKey === 5}
            >
              <RazorPay recentBooking={recentBooking} />
            </CTabPane>

            <CTabPane
              role="tabpanel"
              aria-labelledby="zomoto"
              visible={activeKey === 6}
            >
              <Zometo recentBooking={recentBooking} />
            </CTabPane>

            <CTabPane
              role="tabpanel"
              aria-labelledby="swiggy"
              visible={activeKey === 7}
            >
              <Swiggy recentBooking={recentBooking} />
            </CTabPane>

            <CTabPane
              role="tabpanel"
              aria-labelledby="returnbill"
              visible={activeKey === 8}
            >
              <ReturnBIll />
            </CTabPane>
          </CTabContent>
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setVisible(false)}>
            Close
          </CButton>
        </CModalFooter>
      </CModal>{" "}
    </>
  );
};
export default RecentInvoice;
