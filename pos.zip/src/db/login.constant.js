export const logInResponse = [
  {
    token:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyIwIjp7InVzZXJfaWQiOjEsInVzZXJfZW1haWwiOiJuYXZlZW5Ac3lucXVlcy5pbiIsInVzZXJfcGFzc3dvcmQiOiJuYXNodWJoYTEiLCJ1c2VyX25hbWUiOiJOYXZlZW4iLCJtbmFtZSI6IiIsImdlbmRlciI6Ik1hbGUiLCJhZGRyZXNzIjoiQi0yMTUsIFNoYWhwdXJhLCBCaG9wYWwiLCJ1c2VyX21vYmlsZSI6OTIwMDAwOTc3NywibG9nIjpudWxsLCJ1c2VyX3N0YXR1cyI6MSwidXNlcl9sb2dpbl9zdGF0dXMiOjEsInVzZXJfdHlwZSI6MSwiYXNzaWduZWRfb3V0bGV0X2lkcyI6IjEsMiwzLDQsNSw2IiwiYXNzaWduZWRfbWVudXNfaWRzIjoiNTksNDgsMSwxMCw1MSw1Miw0MCw0NywxMSwxMiwyLDUwLDQ2LDMsNDEsNSwyNCwyNywzMiwzNCw2Miw0Myw0NCw2Niw0LDksMjEsNDYsNTUsMzMsNjAsMzgsNzAsNiw3LDIyLDI4LDUzLDU0LDIwLDIzLDI2LDM1LDM5LDI1LDcyLDU3LDMxLDM2LDM3LDcxLDE0LDY0LDMwLDQ1LDE1LDE3LDU2LDI5LDczLDgsNDIsNjUsNTgsNjEsNjksNjgsNjMiLCJlYnkiOjEsImVhdCI6IjIwMTktMDItMjdUMTA6MTA6NTEuMDAwWiJ9LCJpYXQiOjE2ODkxMzg1NzEsImV4cCI6MTY4OTM5Nzc3MX0.prHIrJjqOqKCd4zFktU7N8VJogIAT9YGH3FfXDdqfXE",
  },
];

export const verifiedTokenData = [
  {
    userdetails: {
      user_id: 1,
      user_email: "naveen@synques.in",
      user_password: "nashubha1",
      user_name: "Naveen",
      mname: "",
      gender: "Male",
      address: "B-215, Shahpura, Bhopal",
      user_mobile: 9200009777,
      log: null,
      user_status: 1,
      user_login_status: 1,
      user_type: 1,
      assigned_outlet_ids: "1,2,3,4,5,6",
      assigned_menus_ids:
        "59,48,1,10,51,52,40,47,11,12,2,50,46,3,41,5,24,27,32,34,62,43,44,66,4,9,21,46,55,33,60,38,70,6,7,22,28,53,54,20,23,26,35,39,25,72,57,31,36,37,71,14,64,30,45,15,17,56,29,73,8,42,65,58,61,69,68,63",
      eby: 1,
      eat: "2019-02-27T10:10:51.000Z",
    },
    exp: "1689397771",
  },
];

// export const logInResponse = [
//   {
//     token:
//       "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyIwIjp7InVzZXJfaWQiOjEsInVzZXJfZW1haWwiOiJuYXZlZW5Ac3lucXVlcy5pbiIsInVzZXJfcGFzc3dvcmQiOiJuYXNodWJoYTEiLCJ1c2VyX25hbWUiOiJOYXZlZW4iLCJtbmFtZSI6IiIsImdlbmRlciI6Ik1hbGUiLCJhZGRyZXNzIjoiQi0yMTUsIFNoYWhwdXJhLCBCaG9wYWwiLCJ1c2VyX21vYmlsZSI6OTIwMDAwOTc3NywibG9nIjpudWxsLCJ1c2VyX3N0YXR1cyI6MSwidXNlcl9sb2dpbl9zdGF0dXMiOjEsInVzZXJfdHlwZSI6MSwiYXNzaWduZWRfb3V0bGV0X2lkcyI6IjEsMiwzLDQsNSw2IiwiYXNzaWduZWRfbWVudXNfaWRzIjoiNTksNDgsMSwxMCw1MSw1Miw0MCw0NywxMSwxMiwyLDUwLDQ2LDMsNDEsNSwyNCwyNywzMiwzNCw2Miw0Myw0NCw2Niw0LDksMjEsNDYsNTUsMzMsNjAsMzgsNzAsNiw3LDIyLDI4LDUzLDU0LDIwLDIzLDI2LDM1LDM5LDI1LDcyLDU3LDMxLDM2LDM3LDcxLDE0LDY0LDMwLDQ1LDE1LDE3LDU2LDI5LDczLDgsNDIsNjUsNTgsNjEsNjksNjgsNjMiLCJlYnkiOjEsImVhdCI6IjIwMTktMDItMjdUMTA6MTA6NTEuMDAwWiJ9LCJpYXQiOjE2ODkxMzg1NzEsImV4cCI6MTY4OTM5Nzc3MX0.prHIrJjqOqKCd4zFktU7N8VJogIAT9YGH3FfXDdqfXE",
//     exp: "1689397771",
//     userdetails: {
//       user_id: 1,
//       user_email: "naveen@synques.in",
//       user_password: "nashubha1",
//       user_name: "Naveen",
//       mname: "",
//       gender: "Male",
//       address: "B-215, Shahpura, Bhopal",
//       user_mobile: 9200009777,
//       log: null,
//       user_status: 1,
//       user_login_status: 1,
//       user_type: 1,
//       assigned_outlet_ids: "1,2,3,4,5,6",
//       assigned_menus_ids:
//         "59,48,1,10,51,52,40,47,11,12,2,50,46,3,41,5,24,27,32,34,62,43,44,66,4,9,21,46,55,33,60,38,70,6,7,22,28,53,54,20,23,26,35,39,25,72,57,31,36,37,71,14,64,30,45,15,17,56,29,73,8,42,65,58,61,69,68,63",
//       eby: 1,
//       eat: "2019-02-27T10:10:51.000Z",
//     },
//   },
// ];
