import React from 'react'

const PendingOrders = () => {
  return (
    <div>PendingOrders</div>
  )
}

export default PendingOrders