import React from "react";

import {
  CFormInput,
  CCol,
  CButton,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
  CInputGroup,
} from "@coreui/react";

const ToppingsModal = () => {
  return (
  
<>sdafasd</>

    
  );
};

export default ToppingsModal;
