// export const BASE_URL = "http://posapi.q4hosting.com";
export const BASE_URL = "http://localhost:2000"; 
